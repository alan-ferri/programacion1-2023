﻿namespace Interfaz
{
    partial class MotosUtilitarias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Volver2 = new System.Windows.Forms.Button();
            this.Eliminar = new System.Windows.Forms.Button();
            this.Guardar = new System.Windows.Forms.Button();
            this.textuso = new System.Windows.Forms.TextBox();
            this.Uso = new System.Windows.Forms.Label();
            this.textmarca2 = new System.Windows.Forms.TextBox();
            this.marca = new System.Windows.Forms.Label();
            this.textmodelo2 = new System.Windows.Forms.TextBox();
            this.modelo = new System.Windows.Forms.Label();
            this.textid2 = new System.Windows.Forms.TextBox();
            this.Id = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // Volver2
            // 
            this.Volver2.Location = new System.Drawing.Point(28, 360);
            this.Volver2.Name = "Volver2";
            this.Volver2.Size = new System.Drawing.Size(95, 30);
            this.Volver2.TabIndex = 54;
            this.Volver2.Text = "Volver";
            this.Volver2.UseVisualStyleBackColor = true;
            // 
            // Eliminar
            // 
            this.Eliminar.Location = new System.Drawing.Point(516, 340);
            this.Eliminar.Name = "Eliminar";
            this.Eliminar.Size = new System.Drawing.Size(130, 57);
            this.Eliminar.TabIndex = 53;
            this.Eliminar.Text = "Eiminar";
            this.Eliminar.UseVisualStyleBackColor = true;
            this.Eliminar.Click += new System.EventHandler(this.Eliminar_Click);
            // 
            // Guardar
            // 
            this.Guardar.Location = new System.Drawing.Point(266, 347);
            this.Guardar.Name = "Guardar";
            this.Guardar.Size = new System.Drawing.Size(132, 43);
            this.Guardar.TabIndex = 52;
            this.Guardar.Text = "Guardar";
            this.Guardar.UseVisualStyleBackColor = true;
            this.Guardar.Click += new System.EventHandler(this.Guardar_Click);
            // 
            // textuso
            // 
            this.textuso.Location = new System.Drawing.Point(143, 175);
            this.textuso.Margin = new System.Windows.Forms.Padding(2);
            this.textuso.Name = "textuso";
            this.textuso.Size = new System.Drawing.Size(165, 20);
            this.textuso.TabIndex = 51;
            // 
            // Uso
            // 
            this.Uso.AutoSize = true;
            this.Uso.Location = new System.Drawing.Point(25, 175);
            this.Uso.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Uso.Name = "Uso";
            this.Uso.Size = new System.Drawing.Size(26, 13);
            this.Uso.TabIndex = 50;
            this.Uso.Text = "Uso";
            // 
            // textmarca2
            // 
            this.textmarca2.Location = new System.Drawing.Point(143, 91);
            this.textmarca2.Margin = new System.Windows.Forms.Padding(2);
            this.textmarca2.Name = "textmarca2";
            this.textmarca2.Size = new System.Drawing.Size(165, 20);
            this.textmarca2.TabIndex = 49;
            // 
            // marca
            // 
            this.marca.AutoSize = true;
            this.marca.Location = new System.Drawing.Point(20, 91);
            this.marca.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.marca.Name = "marca";
            this.marca.Size = new System.Drawing.Size(37, 13);
            this.marca.TabIndex = 48;
            this.marca.Text = "Marca";
            // 
            // textmodelo2
            // 
            this.textmodelo2.Location = new System.Drawing.Point(143, 133);
            this.textmodelo2.Margin = new System.Windows.Forms.Padding(2);
            this.textmodelo2.Name = "textmodelo2";
            this.textmodelo2.Size = new System.Drawing.Size(165, 20);
            this.textmodelo2.TabIndex = 47;
            // 
            // modelo
            // 
            this.modelo.AutoSize = true;
            this.modelo.Location = new System.Drawing.Point(20, 133);
            this.modelo.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.modelo.Name = "modelo";
            this.modelo.Size = new System.Drawing.Size(42, 13);
            this.modelo.TabIndex = 46;
            this.modelo.Text = "Modelo";
            this.modelo.Click += new System.EventHandler(this.label7_Click);
            // 
            // textid2
            // 
            this.textid2.Location = new System.Drawing.Point(143, 49);
            this.textid2.Margin = new System.Windows.Forms.Padding(2);
            this.textid2.Name = "textid2";
            this.textid2.Size = new System.Drawing.Size(165, 20);
            this.textid2.TabIndex = 45;
            // 
            // Id
            // 
            this.Id.AutoSize = true;
            this.Id.Location = new System.Drawing.Point(25, 49);
            this.Id.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.Id.Name = "Id";
            this.Id.Size = new System.Drawing.Size(18, 13);
            this.Id.TabIndex = 44;
            this.Id.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(193, 158);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(13, 13);
            this.label2.TabIndex = 43;
            this.label2.Text = "  ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(193, 158);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 42;
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(329, 21);
            this.listBox1.Margin = new System.Windows.Forms.Padding(2);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(335, 264);
            this.listBox1.TabIndex = 41;
            // 
            // MotosUtilitarias
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Volver2);
            this.Controls.Add(this.Eliminar);
            this.Controls.Add(this.Guardar);
            this.Controls.Add(this.textuso);
            this.Controls.Add(this.Uso);
            this.Controls.Add(this.textmarca2);
            this.Controls.Add(this.marca);
            this.Controls.Add(this.textmodelo2);
            this.Controls.Add(this.modelo);
            this.Controls.Add(this.textid2);
            this.Controls.Add(this.Id);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox1);
            this.Name = "MotosUtilitarias";
            this.Text = "MotosUtilitarias";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Volver2;
        private System.Windows.Forms.Button Eliminar;
        private System.Windows.Forms.Button Guardar;
        private System.Windows.Forms.TextBox textuso;
        private System.Windows.Forms.Label Uso;
        private System.Windows.Forms.TextBox textmarca2;
        private System.Windows.Forms.Label marca;
        private System.Windows.Forms.TextBox textmodelo2;
        private System.Windows.Forms.Label modelo;
        private System.Windows.Forms.TextBox textid2;
        private System.Windows.Forms.Label Id;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox1;
    }
}